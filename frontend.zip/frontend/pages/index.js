import React, { useState } from 'react'; // Optional if CSS is global

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('image');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'image':
        return <div>Image Steganography Content</div>;
      case 'audio':
        return <div>Audio Steganography Content</div>;
      case 'file':
        return <div>File-in-Image Steganography Content</div>;
      case 'video':
        return <div>Video Steganography Content</div>;
      default:
        return null;
    }
  };

  return (
    <main>
      <h1>Steganography Web App</h1>

      <div className="tab-container">
        <button
          className={`tab-button ${activeTab === 'image' ? 'active' : ''}`}
          onClick={() => setActiveTab('image')}
        >
          Image Steganography
        </button>
        <button
          className={`tab-button ${activeTab === 'audio' ? 'active' : ''}`}
          onClick={() => setActiveTab('audio')}
        >
          Audio Steganography
        </button>
        <button
          className={`tab-button ${activeTab === 'file' ? 'active' : ''}`}
          onClick={() => setActiveTab('file')}
        >
          File-in-Image Steganography
        </button>
        <button
          className={`tab-button ${activeTab === 'video' ? 'active' : ''}`}
          onClick={() => setActiveTab('video')}
        >
          Video Steganography
        </button>
      </div>

      <div style={{ marginTop: '2rem', width: '100%', maxWidth: '800px' }}>
        {renderTabContent()}
      </div>
    </main>
  );
}
